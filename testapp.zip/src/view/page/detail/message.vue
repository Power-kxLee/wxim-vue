<template>
	<div>
		<app-message></app-message>
	</div>
</template>
<script type="text/javascript">
	import appMessage from '../../common/app-message.vue'
	export default{
		components :{
			appMessage
		}
	}
</script>