<template>
  <div class="invite">
	<div class='invite-cont'>
		
		<mt-cell title="Account balance:" value="$0.00"></mt-cell>
		<mt-cell title="Cash Coupon:" value="$2224.43"></mt-cell>
		
		<mt-cell title="The total amount of the trade:" value="$0.00"></mt-cell>
		<mt-cell title="The actual amount of the trade：" value="$0.00"></mt-cell>
		<mt-cell title="Refund in process:" value="$0.00"></mt-cell>
		<mt-cell title="The actual amount of the required refund:" value="$0.00"></mt-cell>
		<mt-cell title="The actual amount of the refund:" value="$0.00"></mt-cell>
		<mt-cell title="The amount of the disputed bill:" value="$0.00"></mt-cell>
	

	</div>
  </div>
</template>

<script type="text/babel">
  export default {
   
  };
</script>
