//
//  NotificationService.h
//  jpushNotificationService
//
//  Created by wuxingchen on 16/10/10.
//
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
