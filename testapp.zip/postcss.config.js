module.exports = {
  plugins: [
    require('autoprefixer')({ browsers: [ 'last 20 versions', "> 1%"] })
  ]
}