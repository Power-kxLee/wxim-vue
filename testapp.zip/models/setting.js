module.exports = {
	dataBase : "elmont",
	user:"lee",
	password:"lee",
	host:"www.tt-phpmyadmin.com",
	dialect:"mysql",
	port:3306
}